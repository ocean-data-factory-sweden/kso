# Seafloor-segmentation > 2024-05-31 12:29pm
https://universe.roboflow.com/footage/seafloor-segmentation

Provided by a Roboflow user
License: undefined

